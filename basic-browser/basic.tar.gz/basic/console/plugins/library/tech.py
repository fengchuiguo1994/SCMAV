from browser.models import Technology
from fabi.pytools.term import Tabulator, stdin_or_editor

def help():
  return 'Manage the list of technologies'

def config(parser):
  subpar = parser.add_subparsers()
  sub = subpar.add_parser('new', help='Create new technology entry. Description read from stdin, if available')
  sub.add_argument('name', help='Technology name')
  sub.set_defaults(func=_new)
  
  sub = subpar.add_parser('list', help='List all technologies')
  sub.set_defaults(func=_list)

def _new(args):
  tech = Technology(name=args.name)
  tech.descn = stdin_or_editor('Please enter description for technology [%s]'% args.name)
  tech.save()
  _list(args, id=tech.id)

def _list(args, **kw): # kw -> criteria passed to filter
  tabby = Tabulator()
  tabby.add_column('ID', 6, just='right')
  tabby.add_column('Tech', 15, color='red')
  tabby.add_column('Description', 100)
  tabby.print_table((l.id, l.name, l.descn or '-') for l in Technology.objects.filter(**kw))
