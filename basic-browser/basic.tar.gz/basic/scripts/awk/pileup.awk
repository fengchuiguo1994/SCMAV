# Reads 3 columns:
# - position
# - type (open/close)
# - height/intensity (floating point accepted)
#
# and generates a "pileup" number for each base
# position in chromosome (chromsize given as 1st arg)

BEGIN {
  counter = 0;
  level = 0;
}

{
  pos = $1;
  type = $2;
  val = $3;
  limit = (type == "[" ? pos-1 : pos);
  while (counter <= limit) {
    print level;
    counter++;
  }
  level += (type == "[" ? val : -val);
}

END {
  while (counter <= chromsize) {
    print level;
    counter++;
  }
}
