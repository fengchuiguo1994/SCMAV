# Similar to numstream.c, but reads 2 columns per line:
# - position (starts from 1; must be sorted)
# - height/intensity (assumed to be piled-up)
#
# and generates a stream of N numbers, where
# N is the given chromosome size.

BEGIN {
  counter = 1;
  defval = 0;
}

{
  pos = $1;
  val = $2;
  if (pos > chromsize) break;
  while (counter < pos) {
    print defval;
    counter++;
  }
  print int(val + 0.5);
  counter++;
}

END {
  while (counter <= chromsize) {
    print defval;
    counter++;
  }
}
