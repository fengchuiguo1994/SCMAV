%module xpets

%{
#define SWIG_FILE_WITH_INIT
#define PETS_BSIZE 1000
#define MAX_GROUPS 1048576
#define MAX_SEGMENTS_PER_GROUP 4
#define MAX_BITS_PER_SEGMENT 64
#include "xpets.h"
%}

typedef struct pets_node *PET_Struct;

void pets_create (char* inputfile, char* pets_out, char* select_out, char* chromfile, unsigned int maxpets, char *tmpdir);
void pets_create_single (char *inputfile, char *pets_out, char *select_out, char *chromfile, unsigned int max, char *tmpdir);

PET_Struct pets_load (const char *select, const char *pets, unsigned int mode);
void pets_unload (PET_Struct pnode);

PyObject *pets_query (PET_Struct handler, unsigned int chr, unsigned int x, unsigned int y, unsigned int maxpets);
PyObject *pets_query_single (PET_Struct handler, unsigned int chr, unsigned int posx, unsigned int posy, unsigned int maxpets);

