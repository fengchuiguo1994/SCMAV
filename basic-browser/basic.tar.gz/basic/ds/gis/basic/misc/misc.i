 %module misc
 %{
 #include "misc.h"
 %}
 
 %include "misc.h"