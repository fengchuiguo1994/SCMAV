%module rmq

%{
#define SWIG_FILE_WITH_INIT
#define RMQ_BSIZE 256
#include "rmq.h"
%}

typedef struct node *rmq_track;
struct rmq_node;

void      rmq_build (char outfile[], char filename[], int numOfElements);
int       rmq_query (rmq_track t, unsigned int p, unsigned int q);
rmq_track rmq_load (char filename[]);
void      rmq_unload (rmq_track t);
int       rmq_query2 (rmq_track t, unsigned int p, unsigned int q);
