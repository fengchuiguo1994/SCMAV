%module seq

%{
#include "seq_access.h"
%}

void build(const char* input, const char* outputfile, const char* datadir);
SAHandle load(const char* outputfile);
void unload(SAHandle);
%newobject substring;
char* substring(SAHandle h, unsigned int start, unsigned int length);