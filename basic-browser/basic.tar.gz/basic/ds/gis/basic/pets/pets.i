%module pets

%{
#define SWIG_FILE_WITH_INIT
#define PETS_BSIZE 1000
#include "pets.h"
%}

struct pets_node;

int               pets_create (char* inputfile, char* pets_out, char* select_out, char* chromfile, unsigned int maxpets, char *tmpdir);
int               pets_create_single (char* inputfile, char* pets_out, char* select_out, char* chromfile, unsigned int maxpets, char* tmpdir);
struct pets_node* pets_load (const char *ss, const char *pets, unsigned int num);
PyObject*         pets_query (struct pets_node *handler, unsigned int x, unsigned int y, unsigned int z, unsigned int maxpets);
PyObject*         pets_query_single (struct pets_node *handler, unsigned int x, unsigned int y, unsigned int z, unsigned int maxpets);
void              pets_unload (struct pets_node *pnode);
